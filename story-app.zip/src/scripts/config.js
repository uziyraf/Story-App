const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  VAPID_PUBLIC_KEY: 'BNoEf6-3VYZuTNo4qflAP8HzD9x-BGSOTpGVEz5ZljZPWMXyS54XAViqWCtA6xGYBv2Th7l3859cu6EmIWcetZARB0YJffpOe9UqzIxz5ehYjXxy3sQ',
  ACCESS_TOKEN: 'access-token',
};
export default CONFIG;
